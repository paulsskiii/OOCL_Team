package com.example.day15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day15ApplicationTests {

	@Test
	void contextLoads() {
	}

}
